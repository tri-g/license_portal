import http from "./http-common";

const create = data => {
  return http.post("/tutorials", data);
};
export default {
 
  create
};