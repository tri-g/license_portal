import http from "./http-common";

const create = data => {
  return http.post("/GenerateLicense", data);
};
export default {
 
  create
};