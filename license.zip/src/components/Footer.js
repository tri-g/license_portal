import React from 'react'
import {Container} from "react-bootstrap";
import "../assets/manage.css";


function Footer() {
  return (
    <footer>
      <div id="footer-wrap">
        <Container>
          <p>
            <i className="fa fa-copyright"></i> 2021 SLK Software Services Pvt Ltd. All rights reserved.
          </p>
        </Container>
      </div>
    </footer>
  );
}

export default Footer;