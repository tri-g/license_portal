import React, {useEffect,useState} from 'react'
import {Col, Container, Row} from "react-bootstrap";

function Dashboard() {

	
  return (
    <main className={'class1'}>
    
 <h1>This is Dashboard</h1>
    </main>
  )
}

export default Dashboard
