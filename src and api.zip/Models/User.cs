﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace LicensePortal_APPAPI.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public int ContactNumber { get; set; }
        public string Address { get; set; }
        public DateTime lastlogin { get; set; }
        public string password { get; set; }
    }
    public class record
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public int ContactNumber { get; set; }
        public string Address { get; set; }
        public string password { get; set; }

        public string OrgName { get; set; }

    }
    public class postdatauser
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public int ContactNumber { get; set; }
        public string Address { get; set; }
        public DateTime lastlogin { get; set; }
        public string password { get; set; }
        public int OrgID { get; set; }


    }
    public class postdataorg
    {
        public int OrgID { get; set; }
        public string OrgName { get; set; }
        public string OrgEmailAdd { get; set; }
        public string OrgConNumber { get; set; }
        public string OrgAddress { get; set; }
        public int PostCode { get; set; }
        public string OrgType_name { get; set; }
        public string Description { get; set; }


    }


}
