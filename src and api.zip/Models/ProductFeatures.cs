﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicensePortal_APPAPI.Models
{
    public class ProductFeatures
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
