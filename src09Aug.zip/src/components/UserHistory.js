import {Col, Modal, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import React, {useState} from "react";
import Service from "../app/service/service.js";
import { useHistory } from "react-router-dom";
import Manageusers from "../app/Manage/AddDeleteUser.js";

export default function UserHistory({id, name, email, num, address,initialState}) {
  const [show_video_modal, setVideoModal] = useState(false)
  const history = useHistory();
  const handleClose = () => setShow(false);
  const [info, setInfo] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);

  const handleShow = () =>setShow(true);
  const [showModal, setShow] = useState(false);

  const deleteuser = () => {
   
    Service.deleteUser(id)
      .then(response => {
        console.log(response.data);
        history.push('/adddeleteuser');
        history.go(0);

      })
      .catch(e => {
        console.log(e);
      });
  };
  const handleInputChange = event => {

    const { name, value } = event.target;
    setInfo({ ...info, [event.target.name]: event.target.value });
  };
  const saveInfo = () => {

    var data = {
        userID:id,
        userName: info.userName,
        emailAddress: info.emailAddress,
        contactNumber: +info.contactNumber,
        address:info.address,
        lastlogin: "2020-08-25T18:30:00",
        password: "slk"
    };
    console.log(data);
    Service.updateuser(data,id)
      .then(response => {
        console.log("data");
        setInfo({
            userID:id,
            userName: response.data.userName,
            emailAddress: response.data.emailAddress,
            contactNumber: response.data.contactNumber,
            address:response.data.address,
            lastlogin: "2020-08-25T18:30:00",
        password: "slk"

        });
        console.log("data");

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };

  function success(){
    alert("User updated successfully!");
    window.location.reload();
  }
  return (
    <>                                
                                    <tr>
                                        <td>
                                            {id}
                                        </td>
                                        <td>
                                           {name}
                                        </td>
                                        <td>
                                          {email}
                                        </td>
                                        <td>
                                            {num}
                                        </td>
                                        <td>
                                            {address}
                                        </td>
                                        <td>
                                        <button className="buttonstyle"  style={{paddingRight: "10px"}} onClick={handleShow}><i className="fa fa-pencil"  aria-hidden="true" style={{paddingRight: "5px"}}  data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        <button className="buttonstyle" onClick={deleteuser}><i className="fa fa-trash" aria-hidden="true" data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        </td>
                                       
                                    </tr>
                                    
                                    <Modal id="center" show={showModal} onHide={handleClose}>      
                                    <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Edit User</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>


        <div className="modal-body">
        {submitted ? (
        <div>
     {success()}
    </div>
      ) : (
            <form className="form" role="form" autoComplete="off">
              <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">User ID</label>
                    <div className="col-lg-7">
                        <label className="form-control">{id}</label>
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Name</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="userName" name="userName" onChange={handleInputChange} value={info.userName || name}  placeholder="User Name"/>
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Email</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="email" id="emailAddress" name="emailAddress" onChange={handleInputChange} value={info.emailAddress || ''}  placeholder="Email Address"/>
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Contact No</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="contactNumber" name="contactNumber" onChange={handleInputChange} value={info.contactNumber || ''}  placeholder="Contact Number"/>
                    </div>
                </div>

               <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Address</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="address" name="address" onChange={handleInputChange} value={info.address || ''}  placeholder="Address"/>
                    </div>
                </div>

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary" value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="button" className="btn btn-primary" value="Add" onClick={saveInfo} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>                
                           
    </>
  )
}
