import http from "./http-common";

var message='';
var message1='';

const create = data => {
  return http.post("/GenerateLicense", data);
};

const login_validation = data => {
  return http.post("/token", data);
};

function getuserdetails() {
  return http.get('/token/GetUsers');
}

function setMessage(message){
  localStorage.setItem('message', JSON.stringify(message));
}

function readMessage(){
  var retrievedObject =localStorage.getItem('message');
  message1=JSON.parse(retrievedObject);
  return message1;
}
const deleteUser = id => {
  return http.delete("/token/DeleteUser/"+id);
};
const updateuser = (data,id) => {
  return http.put("/token/Update/"+id, data);
};
const adduser = data => {
  return http.post("/token/AddUser", data);
};
export default {
  create,
  login_validation,
  setMessage,
  readMessage,
  getuserdetails,
  deleteUser,
  updateuser,
  adduser
};