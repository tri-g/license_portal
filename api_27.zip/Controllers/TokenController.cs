﻿using LicensePortal_APPAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Cors;
using System.Collections.Generic;
using LicensePortal_APPAPI.Models;


using System.Net.Http;

namespace LicensePortal_APPAPI.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private DatabaseContext _context;

        //login authentication
        public TokenController(IConfiguration config, DatabaseContext context)
        {
            _configuration = config;
            _context = context;
        }
        [EnableCors]
        [HttpPost]
        public async Task<IActionResult> Post(User _userData)
        {

            if (_userData != null && _userData.EmailAddress != null && _userData.password != null)
            {
                var user = await GetUser(_userData.EmailAddress, _userData.password);

                if (user != null)
                {
                    User u = GetById(_userData.EmailAddress);
                    var claims = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),

                   };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));

                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddDays(1), signingCredentials: signIn);

                    return Ok(u.UserName);
                }
                else
                {
                    return BadRequest("Invalid credentials");
                }
            }
            else
            {
                return BadRequest();
            }
        }

        private async Task<User> GetUser(string email, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.EmailAddress == email && u.password == password);
        }

        public User GetById(string email)
        {
            return _context.Users.Where(x => x.EmailAddress == email).FirstOrDefault();
        }

        //get user details
        [HttpGet]
        [Route("GetUsers")]
        public IEnumerable<record> Get()
        {
            List<record> objourney = new List<record>();

            //var result = _context.Users.ToList();
            var obj = (from u in _context.Users
                       join ou in _context.Org_User
                      on u.UserID equals ou.UserID
                      join o in _context.Organization
                      on ou.OrgID equals o.OrgID
                      select new
                      {
                          u.UserID,
                         u.UserName,
                          u.EmailAddress,
                          u.ContactNumber,
                          u.Address,
                          o.OrgName
                      }).ToList();
            foreach (var p in obj)
            {
                record r = new record();
                r.UserID = p.UserID;
                r.UserName = p.UserName;
                r.EmailAddress = p.EmailAddress;
                r.ContactNumber = p.ContactNumber;
                r.Address = p.Address;
                r.OrgName = p.OrgName;
                objourney.Add(r);
                
            }

            return objourney;


        }

        //add user
        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> POST(postdatauser _userData)
        {
            User us = new User();
            Org_User ou = new Org_User();
            us.UserID = _userData.UserID;
            us.UserName = _userData.UserName;
            us.Address = _userData.Address;
            us.ContactNumber = _userData.ContactNumber;
            us.EmailAddress = _userData.EmailAddress;
            us.lastlogin = _userData.lastlogin;
            us.password = _userData.password;
            _context.Users.Add(us);
            _context.SaveChanges();
            ou.UserID = us.UserID;

            ou.OrgID = _userData.OrgID;
            _context.Org_User.Add(ou);
            _context.SaveChanges();

            return Ok();
        }


        //get organization details
        [HttpGet]
        [Route("GetOrganization")]
        public IEnumerable<Organization> Getdata()
        {
            var result = _context.Organization.ToList();
            return result;
        }

        //add organization
        [HttpPost]
        [Route("AddOrganization")]
        public async Task<IActionResult> POSTorg(postdataorg _orgData)
        {
            Organization or = new Organization();
            OrgType ot = new OrgType();
            or.OrgID = _orgData.OrgID;
            or.OrgName = _orgData.OrgName;
            or.OrgEmailAdd = _orgData.OrgEmailAdd;
            or.OrgAddress = _orgData.OrgAddress;
            or.PostCode = _orgData.PostCode;
            or.OrgConNumber = _orgData.OrgConNumber;
            _context.Organization.Add(or);
            _context.SaveChanges();
           ot.OrgType_name = _orgData.OrgType_name;
            ot.Description = _orgData.Description;
            ot.OrgID = or.OrgID;
            _context.OrgType.Add(ot);
            _context.SaveChanges();

            return Ok();
        }

        //get roles
        [HttpGet]
        [Route("RoleType")]
        public IEnumerable<Roles> Getrole()
        {
            var result = _context.Roles.ToList();
            return result;
        }

        //update user
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> Edit(int id, postdatauser _userData)
        {
            if (!ModelState.IsValid)
            {
                return NotFound();
            }
            try
            {
                var dbUser = _context.Users
     .FirstOrDefault(s => s.UserID.Equals(id));
                var dbOrgUser = _context.Org_User
                      .FirstOrDefault(s => s.UserID.Equals(id));
                dbUser.UserName = _userData.UserName;
                dbUser.Address = _userData.Address;
                dbUser.ContactNumber = _userData.ContactNumber;
                dbUser.EmailAddress = _userData.EmailAddress;
                /* dbUser.lastlogin = _userData.lastlogin;
                 dbUser.password = _userData.password;*/


                _context.SaveChanges();
                dbOrgUser.UserID = id;
                dbOrgUser.OrgID = _userData.OrgID;
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

      

        [HttpPut("Updateorg/{id}")]
        public async Task<IActionResult> Editorg(int id, Organization _orgData)
        {
            if (!ModelState.IsValid)
            {
                return NotFound();
            }
            try
            {
                var dbOrg= _context.Organization
     .FirstOrDefault(s => s.OrgID.Equals(id));
                
                dbOrg.OrgName = _orgData.OrgName;
                dbOrg.OrgEmailAdd = _orgData.OrgEmailAdd;
                dbOrg.OrgConNumber = _orgData.OrgConNumber;
                dbOrg.OrgAddress = _orgData.OrgAddress;
                dbOrg.PostCode = _orgData.PostCode;
                _context.SaveChanges();
               
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrgExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        //delete user
        [HttpDelete("DeleteUser/{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var users = await _context.Users.FindAsync(id);
            if (users == null)
            {
                return NotFound();
            }
            _context.Users.Remove(users);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("DeleteOrganization/{id}")]
        public async Task<ActionResult<User>> DeleteOrganization(int id)
        {
            var org = await _context.Organization.FindAsync(id);
            if (org == null)
            {
                return NotFound();
            }
            _context.Organization.Remove(org);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool UserExists(int id)
        {
            throw new NotImplementedException();
        }
        private bool OrgExists(int id)
        {
            throw new NotImplementedException();
        }
    }
}