﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LicensePortal_APPAPI.Models
{
    public class OrgType
    {
        [Key]
        public int OrgType_ID { get; set; }
        public string OrgType_name { get; set; }
        public string Description { get; set; }
        public int OrgID { get; set; }
    }
}
