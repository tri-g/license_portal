import {Col, Modal, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import React, {useState} from "react";
import Service from "../app/service/service.js";
import { useHistory } from "react-router-dom";
import Manageusers from "../app/Manage/AddDeleteUser.js";

export default function UserHistory({id, name, email, num, address,orgname,initialState,org,val}) {
  const [show_video_modal, setVideoModal] = useState(false)
  const history = useHistory();
  const handleClose = () => setShow(false);
  const [info, setInfo] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);

  const handleShow = () =>{setShow(true);setShow2(true);
  setName(name);
  setEmail(email);
  setCon(num);
  setAddress(address);


}
  const [showModal, setShow] = useState(false);
  const handleShow1 = () => setShow1(true);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);


  const handleClose1 = () => {setShow1(false);}
  const deleteuser = () => {
   
    Service.deleteUser(id)
      .then(response => {
        console.log(response.data);
        history.push('/adddeleteuser');
        history.go(0);

      })
      .catch(e => {
        console.log(e);
      });
  };

  const [uid, setId] = useState(id);
  const [uname, setName] = useState(name);
  const [uemail, setEmail] = useState(email);
  const [unum, setCon] = useState(num);
  const [uaddress, setAddress] = useState(address);
  const [valu, setValue] = useState(val);


  const saveInfo = () => {

    var data = {
        userName: uname,
        emailAddress: uemail,
        contactNumber: +unum,
        address:uaddress,
       
        OrgID:+valu
    };
   
  
    console.log(data);
    Service.updateuser(data,id)
      .then(response => {
        console.log("data");
        setInfo({
            userID:id,
            userName: response.data.userName,
            emailAddress: response.data.emailAddress,
            contactNumber: response.data.contactNumber,
            address:response.data.address,
          
        orgID: response.data.OrgID

        });
        console.log(data);

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };

  function success(){
    
    window.location.reload();
  }
  return (
    <>                                
                                    
                                    <tr>
                                        <td>
                                            {id}
                                        </td>
                                        <td>
                                           {name}
                                        </td>
                                        <td>
                                          {email}
                                        </td>
                                        <td>
                                            {num}
                                        </td>
                                        <td>
                                            {address}
                                        </td>
                                        <td>
                                            {orgname}
                                        </td>
                                        <td>
                                        <button className="buttonstyle"  style={{paddingRight: "10px"}} onClick={handleShow}><i className="fa fa-pencil"  aria-hidden="true" style={{paddingRight: "5px"}}  data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        <button className="buttonstyle" onClick={handleShow1}><i className="fa fa-trash" aria-hidden="true" data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        </td>
                                       
                                    </tr>
                                    
                                    <Modal id="center" show={showModal} onHide={handleClose}>      
                                    <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Edit User</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>


        <div className="modal-body">
        {submitted ? (
        <div>
    <Modal id="center" show={show2} onHide={handleClose1}>
          <div className="modal-body">
          <h2>User Edited Successfully!</h2>
       
          <input type="reset" className="btn btn-secondary" style={{width:"10%",float:"right",height:"3%"}} onClick={success} value="OK"/>
             
        </div>
        </Modal>
    </div>
      ) : (
            <form className="form" role="form" autoComplete="off">
               <div className="form-group row">
            <label className="col-lg-5 col-form-label form-control-label" htmlFor="licensetype">Organization</label>
           <div className="col-lg-7">
             <select className="form-control selectpicker" id="select-country" data-live-search="true" name="org" value={valu}
      onChange={(e) => setValue(e.currentTarget.value)}>
            
             {org.map((item,value) => (
        <option
          key={value}
          value={item.orgID}
        >
         {item.orgName}
        </option>
      ))}
          </select>
          
          </div></div>
         
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Name</label>
                    <div className="col-lg-7">
                        <input id="id1" className="form-control"  type="text" id="userName" name="userName"  onChange={(e) => setName(e.currentTarget.value)} value={uname}  placeholder="User Name"/>
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Email</label>
                    <div className="col-lg-7">
                        <input id="id2" className="form-control" type="email" id="emailAddress" name="emailAddress" onChange={(e) => setEmail(e.currentTarget.value)} value={uemail} placeholder="Email Address"/>
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Contact No</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="contactNumber" name="contactNumber" onChange={(e) => setCon(e.currentTarget.value)} value={unum}  placeholder="Contact Number"/>
                    </div>
                </div>

               <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Address</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="address" name="address"  onChange={(e) => setAddress(e.currentTarget.value)} value={uaddress}  placeholder="Address"/>
                    </div>
                </div>
              

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary" onClick={handleClose} value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="button" className="btn btn-primary" value="Add" onClick={saveInfo} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>  

            <Modal show={show1} onHide={handleClose1} style={{top:"30%"}}>
          <div className="modal-body">
          <h5> Are you sure you want to continue?</h5>
       <div style={{textAlign:'center'}}>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%",marginRight:"10px"}} onClick={deleteuser} value="Yes"/>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%"}} onClick={handleClose1} value="No"/>
          </div>
        </div>
      </Modal>              
                           
    </>
  )
}
