import {Col, Modal, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import React, {useState} from "react";
import Service from "../app/service/service.js";
import { useHistory } from "react-router-dom";
import Manageusers from "../app/Manage/AddDeleteUser.js";

export default function OrganizationHistory({id, name, email, num, address,postcode,initialState}) {
  const [show_video_modal, setVideoModal] = useState(false)
  const history = useHistory();
  const handleClose = () => setShow(false);
  const [info, setInfo] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);
  const [show2, setShow2] = useState(false);

  const handleShow = () =>{setShow(true);setShow2(true);
    setName(name);
    setEmail(email)
    setCon(num);
    setAddress(address);
    setPostcode(postcode);
  
  }
  const [showModal, setShow] = useState(false);
  const handleShow1 = () => setShow1(true);
  const [show1, setShow1] = useState(false);
  const [value, setValue] = useState();

  const [oname, setName] = useState(name);
  const [oemail, setEmail] = useState(email);
  const [onum, setCon] = useState(num);
  const [oaddress, setAddress] = useState(address);
  const [opostcode, setPostcode] = useState(postcode);

  const handleClose1 = () => {setShow1(false);}
  const deleteuser = () => {
   
    Service.deleteOrganization(id)
      .then(response => {
        console.log(response.data);
        history.push('/addorganization');
        history.go(0);

      })
      .catch(e => {
        console.log(e);
      });
  };
  const handleInputChange = event => {

    const { name, value } = event.currentTarget;
    setInfo({ ...info, [name]: value });
    
  };
  const saveInfo = () => {
   

    var data = {
        orgName: oname,
        orgEmailAdd: oemail,
        orgConNumber:onum,
        orgAddress: oaddress,
        postCode:+opostcode
        
    };
  
    console.log(data);
    Service.updateorg(data,id)
      .then(response => {
        console.log("data");
        setInfo({
          orgID:response.data.orgID,
          orgName: response.data.orgName,
          orgEmailAdd: response.data.orgEmailAdd,
          orgConNumber: response.data.orgConNumber,
          orgAddress:response.data.orgAddress,
          postCode: response.data.postCode
        });
        console.log("data");

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };

  function success(){
   
    window.location.reload();
  }
  return (
    <>                                
                                    <tr>
                                        <td>
                                            {id}
                                        </td>
                                        <td>
                                           {name}
                                        </td>
                                        <td>
                                          {email}
                                        </td>
                                        <td>
                                            {num}
                                        </td>
                                        <td>
                                            {address}
                                        </td>
                                        <td>
                                            {postcode}
                                        </td>
                                        <td>
                                        <button className="buttonstyle"  style={{paddingRight: "10px"}} onClick={handleShow}><i className="fa fa-pencil"  aria-hidden="true" style={{paddingRight: "5px"}}  data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        <button className="buttonstyle" onClick={handleShow1}><i className="fa fa-trash" aria-hidden="true" data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        </td>
                                       
                                    </tr>
                                    
                                    <Modal style={{top:"10%"}} show={showModal} onHide={handleClose}>      
                                    <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Edit Organization</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>


        <div className="modal-body">
        {submitted ? (
            <div>
            <Modal id="center" show={show2} onHide={handleClose1}>
                  <div className="modal-body">
                  <h2>Organization Edited Successfully!</h2>
               
                  <input type="reset" className="btn btn-secondary" style={{width:"10%",float:"right",height:"3%"}} onClick={success} value="OK"/>
                     
                </div>
                </Modal>
            </div>
      ) : (
            <form className="form" role="form" autoComplete="off">  
            <div className="form-group row">
                
                <label className="col-lg-5 col-form-label form-control-label">Name</label>

                <div className="col-lg-7">
               
                    <input className="form-control" type="text" id="orgName" name="orgName" onChange={(e) => setName(e.currentTarget.value)} value={oname}   placeholder="Organization Name"/>
                </div>
            </div>
            <div className="form-group row">
                <label className="col-lg-5 col-form-label form-control-label">Email</label>
                <div className="col-lg-7">
                    <input className="form-control" type="email" id="orgEmailAdd" name="orgEmailAdd" onChange={(e) => setEmail(e.currentTarget.value)} value={oemail}  placeholder="Email Address"/>
                </div>
            </div>

            <div className="form-group row">
                <label className="col-lg-5 col-form-label form-control-label">Contact No</label>
                <div className="col-lg-7">
                    <input className="form-control" type="text" id="orgConNumber" name="orgConNumber" onChange={(e) => setCon(e.currentTarget.value)} value={onum}  placeholder="Contact Number"/>
                </div>
            </div>

           <div className="form-group row">
                <label className="col-lg-5 col-form-label form-control-label">Address</label>
                <div className="col-lg-7">
                    <input className="form-control" type="text" id="orgAddress" name="orgAddress" onChange={(e) => setAddress(e.currentTarget.value)} value={oaddress}  placeholder="Address"/>
                </div>
            </div>

            <div className="form-group row">
                <label className="col-lg-5 col-form-label form-control-label">Post Code</label>
                <div className="col-lg-7">
                    <input className="form-control" type="text" id="postCode" name="postCode" onChange={(e) => setPostcode(e.currentTarget.value)} value={opostcode}  placeholder="Post Code"/>
                </div>
            </div>

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary" onClick={handleClose} value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="button" className="btn btn-primary" value="Add" onClick={saveInfo} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>  

            <Modal id="center" show={show1} onHide={handleClose1}>
          <div className="modal-body">
          <h5> Are you sure you want to continue?</h5>
       <div style={{textAlign:'center'}}>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%",marginRight:"10px"}} onClick={deleteuser} value="Yes"/>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%"}} onClick={handleClose1} value="No"/>
          </div>
        </div>
      </Modal>              
                           
    </>
  )
}
