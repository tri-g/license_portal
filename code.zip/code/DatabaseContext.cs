﻿using Microsoft.EntityFrameworkCore;
using LicensePortal_APPAPI.Models;
namespace LicensePortal_APPAPI
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Org_User> Org_User { get; set; }
        public DbSet<Roles> Roles { get; set; }
        public DbSet<Organization> Organization { get; set; }
        public DbSet<OrgType> OrgType { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<Org_Products> Org_Products { get; set; }



    }
}