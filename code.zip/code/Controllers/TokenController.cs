﻿using LicensePortal_APPAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Cors;
using System.Collections.Generic;
using LicensePortal_APPAPI.Models;


using System.Net.Http;

namespace LicensePortal_APPAPI.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private DatabaseContext _context;

        //login authentication
        public TokenController(IConfiguration config, DatabaseContext context)
        {
            _configuration = config;
            _context = context;
        }
        [EnableCors]
        [HttpPost]
        public async Task<IActionResult> Post(User _userData)
        {

            if (_userData != null && _userData.EmailAddress != null && _userData.password != null)
            {
                var user = await GetUser(_userData.EmailAddress, _userData.password);

                if (user != null)
                {
                    User u = GetById(_userData.EmailAddress);
                    var claims = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),

                   };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));

                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddDays(1), signingCredentials: signIn);

                    return Ok(u.UserName);
                }
                else
                {
                    return BadRequest("Invalid credentials");
                }
            }
            else
            {
                return BadRequest();
            }
        }

        private async Task<User> GetUser(string email, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.EmailAddress == email && u.password == password);
        }

        public User GetById(string email)
        {
            return _context.Users.Where(x => x.EmailAddress == email).FirstOrDefault();
        }

        //get user details
        [HttpGet]
        [Route("GetUsers")]
        public IEnumerable<record> Get()
        {
            List<record> objourney = new List<record>();

            //var result = _context.Users.ToList();
            var obj = (from u in _context.Users
                       join ou in _context.Org_User
                      on u.UserID equals ou.UserID
                      join o in _context.Organization
                      on ou.OrgID equals o.OrgID
                      select new
                      {
                          u.UserID,
                         u.UserName,
                          u.EmailAddress,
                          u.ContactNumber,
                          u.Address,
                          u.password,
                          o.OrgName
                      }).ToList();
            foreach (var p in obj)
            {
                record r = new record();
                r.UserID = p.UserID;
                r.UserName = p.UserName;
                r.EmailAddress = p.EmailAddress;
                r.ContactNumber = p.ContactNumber;
                r.Address = p.Address;
                r.password = p.password;
                r.OrgName = p.OrgName;
                objourney.Add(r);
                
            }

            return objourney;


        }

        //add user
        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> POST(postdatauser _userData)
        {
            User us = new User();
            Org_User ou = new Org_User();
            us.UserName = _userData.UserName;
            us.Address = _userData.Address;
            us.ContactNumber = _userData.ContactNumber;
            us.EmailAddress = _userData.EmailAddress;
            us.lastlogin = _userData.lastlogin;
            us.password = _userData.password;
            _context.Users.Add(us);
            _context.SaveChanges();
            ou.UserID = us.UserID;

            ou.OrgID = _userData.OrgID;
            _context.Org_User.Add(ou);
            _context.SaveChanges();

            return Ok();
        }


        //get organization details
        [HttpGet]
        [Route("GetOrganization")]

       
        
        public IEnumerable<record1> Getdata()
        {
        List<record1> objourney = new List<record1>();
            var obj = (from o in _context.Organization
                       join ot in _context.OrgType
                      on o.OrgID equals ot.OrgID
                       select new
                       {
                           o.OrgID,
                           o.OrgName,
                           o.OrgEmailAdd,
                           o.OrgConNumber,
                           o.OrgAddress,
                           o.PostCode,
                           ot.OrgType_name,
                           ot.Description
                       })
            .ToList();
            foreach (var p in obj)
            {
                record1 r = new record1();
                r.OrgID = p.OrgID;
                r.OrgName = p.OrgName;
                r.OrgEmailAdd = p.OrgEmailAdd;
                r.OrgConNumber = p.OrgConNumber;
                r.OrgAddress = p.OrgAddress;
                r.PostCode = p.PostCode;
                r.OrgType_name = p.OrgType_name;
                r.Description = p.Description;
                objourney.Add(r);

            }

            return objourney;
           
        }

        //add organization
        [HttpPost]
        [Route("AddOrganization")]
        public async Task<IActionResult> POSTorg(postdataorg _orgData)
        {
            Organization or = new Organization();
            OrgType ot = new OrgType();
           
            or.OrgName = _orgData.OrgName;
            or.OrgEmailAdd = _orgData.OrgEmailAdd;
            or.OrgAddress = _orgData.OrgAddress;
            or.PostCode = _orgData.PostCode;
            or.OrgConNumber = _orgData.OrgConNumber;
            _context.Organization.Add(or);
            _context.SaveChanges();
           ot.OrgType_name = _orgData.OrgType_name;
            ot.Description = _orgData.Description;
            ot.OrgID = or.OrgID;
            _context.OrgType.Add(ot);
            _context.SaveChanges();

            return Ok();
        }

        //get roles
        [HttpGet]
        [Route("RoleType")]
        public IEnumerable<Roles> Getrole()
        {
            var result = _context.Roles.ToList();
            return result;
        }

        //update user
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> Edit(int id, postdatauser _userData)
        {
            if (!ModelState.IsValid)
            {
                return NotFound();
            }
            try
            {
                var dbUser = _context.Users
     .FirstOrDefault(s => s.UserID.Equals(id));
                var dbOrgUser = _context.Org_User
                      .FirstOrDefault(s => s.UserID.Equals(id));
                dbUser.UserName = _userData.UserName;
                dbUser.Address = _userData.Address;
                dbUser.ContactNumber = _userData.ContactNumber;
                dbUser.EmailAddress = _userData.EmailAddress;
                /* dbUser.lastlogin = _userData.lastlogin;*/
                 dbUser.password = _userData.password;


                _context.SaveChanges();
                dbOrgUser.UserID = id;
                dbOrgUser.OrgID = _userData.OrgID;
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

      

        [HttpPut("Updateorg/{id}")]
        public async Task<IActionResult> Editorg(int id, record1 _orgData)
        {
            if (!ModelState.IsValid)
            {
                return NotFound();
            }
            try
            {
                var dbOrg= _context.Organization
     .FirstOrDefault(s => s.OrgID.Equals(id));
                var dbOrg1 = _context.OrgType
    .FirstOrDefault(s => s.OrgID.Equals(id));
                dbOrg.OrgName = _orgData.OrgName;
                dbOrg.OrgEmailAdd = _orgData.OrgEmailAdd;
                dbOrg.OrgConNumber = _orgData.OrgConNumber;
                dbOrg.OrgAddress = _orgData.OrgAddress;
                dbOrg.PostCode = _orgData.PostCode;

                _context.SaveChanges();
                dbOrg1.OrgType_name = _orgData.OrgType_name;
                dbOrg1.Description = _orgData.Description;
                _context.SaveChanges();

            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrgExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        //delete user
        [HttpDelete("DeleteUser/{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var users = await _context.Users.FindAsync(id);
            if (users == null)
            {
                return NotFound();
            }
            _context.Users.Remove(users);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("DeleteOrganization/{id}")]
        public async Task<ActionResult<User>> DeleteOrganization(int id)
        {
            var org = await _context.Organization.FindAsync(id);
            if (org == null)
            {
                return NotFound();
            }
            _context.Organization.Remove(org);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool UserExists(int id)
        {
            throw new NotImplementedException();
        }
        private bool OrgExists(int id)
        {
            throw new NotImplementedException();
        }
        [HttpGet]
        [Route("Products")]
        public IEnumerable<prodrecord> Getprod()
        {
            List<prodrecord> objourney = new List<prodrecord>();

            //var result = _context.Users.ToList();
            var obj = (from p in _context.Products
                       join op in _context.Org_Products
                      on p.ProductID equals op.ProductID
                       join o in _context.Organization
                       on op.OrgID equals o.OrgID
                       select new
                       {
                           p.ProductID,
                           p.PrdName,
                           p.PrdDesc,
                           p.ProductCode,
                           p.PrdVersion,
                           o.OrgName
                       }).ToList();
            foreach (var p in obj)
            {
                prodrecord r = new prodrecord();
                r.ProductID = p.ProductID;
                r.PrdName = p.PrdName;
                r.PrdDesc = p.PrdDesc;
                r.ProductCode = p.ProductCode;
                r.PrdVersion = p.PrdVersion;
                r.OrgName = p.OrgName;
                objourney.Add(r);

            }

            return objourney;

        }
        [HttpPost]
        [Route("AddProduct")]
        public async Task<IActionResult> AddProduct(Postprodrecord _userData)
        {
           Products p = new Products();
           Org_Products op = new Org_Products();
            p.PrdName = _userData.PrdName;
            p.PrdDesc = _userData.PrdDesc;
            p.ProductCode = _userData.ProductCode;
            p.PrdVersion = _userData.PrdVersion;
            _context.Products.Add(p);
            _context.SaveChanges();
            op.ProductID = p.ProductID;
            op.OrgID = _userData.OrgID;
            _context.Org_Products.Add(op);
            _context.SaveChanges();

            return Ok();
        }
        [HttpPut("UpdateProd/{id}")]
        public async Task<IActionResult> Updateproduct(int id, Postprodrecord _userData)
        {
            if (!ModelState.IsValid)
            {
                return NotFound();
            }
            try
            {
                var dbProd = _context.Products
     .FirstOrDefault(s => s.ProductID.Equals(id));
                var dbOrgProd = _context.Org_Products
                      .FirstOrDefault(s => s.ProductID.Equals(id));
                dbProd.PrdName = _userData.PrdName;
                dbProd.PrdDesc = _userData.PrdDesc;
                dbProd.ProductCode = _userData.ProductCode;
                dbProd.PrdVersion = _userData.PrdVersion;
                _context.SaveChanges();
                dbOrgProd.ProductID = id;
                dbOrgProd.OrgID = _userData.OrgID;
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }
        [HttpDelete("DeleteProd/{id}")]
        public async Task<ActionResult<User>> DeleteProduct(int id)
        {
            var prods = await _context.Products.FindAsync(id);
            if (prods == null)
            {
                return NotFound();
            }
            _context.Products.Remove(prods);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}