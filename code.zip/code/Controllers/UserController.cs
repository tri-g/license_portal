﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using LicensePortal_APPAPI.Models;
using LicensePortal_APPAPI.Services;
using System.Threading.Tasks;
using System;

namespace LicensePortal_APPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        [Route("[action]")]
        [Route("api/User/GetUsers")]
        public IEnumerable<User> GetUsers()
        {
            return _userService.GetUser();
        }

        [HttpDelete]
        [Route("[action]")]
        [Route("api/User/DeleteUser/{name}")]
        public IActionResult DeleteUsers(string name)
        {
            try
            {
                var existingEmployee = _userService.GetUser(name);
                if (existingEmployee != null)
                {
                    _userService.DeleteUser(existingEmployee.UserName);
                    return Ok();
                }

                return NotFound($"Employee Not Found with ID : {existingEmployee.UserName}");
            }
            catch (Exception)
            {
               return NotFound($"Employee Not Found with ID");
            }
            
        }
        [HttpGet]
        [Route("GetEmployee")]
        public User GetEmployee(string name)
        {
            return _userService.GetUser(name);
        }
        [HttpPost]
        [Route("[action]")]
        [Route("api/Employee/AddEmployee")]
        public IActionResult AddEmployee(User user)
        {
            _userService.AddUser(user);
            return Ok();
        }

        /*  

          [HttpPost]
          [Route("[action]")]
          [Route("api/Employee/UpdateEmployee")]
          public IActionResult UpdateEmployee(Employee employee)
          {
              _employeeService.UpdateEmployee(employee);
              return Ok();
          }

          

          [HttpGet]
          [Route("GetEmployee")]
          public Employee GetEmployee(int id)
          {
              return _employeeService.GetEmployee(id);
          }*/

    }
}