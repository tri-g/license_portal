﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LicensePortal_APPAPI.Models
{
    public class Products
    {
        [Key]
        public int ProductID { get; set; }
        public string PrdName { get; set; }
        public string PrdDesc { get; set; }
        public string ProductCode { get; set; }
        public string PrdVersion { get; set; }

    }
    public class prodrecord
    {
        public int ProductID { get; set; }
        public string PrdName { get; set; }
        public string PrdDesc { get; set; }
        public string ProductCode { get; set; }
        public string PrdVersion { get; set; }
        public string OrgName { get; set; }

    }
    public class Postprodrecord
    {
        public int ProductID { get; set; }
        public string PrdName { get; set; }
        public string PrdDesc { get; set; }
        public string ProductCode { get; set; }
        public string PrdVersion { get; set; }
        public int OrgID { get; set; }

    }
  
}
