﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


#nullable disable

namespace LicensePortal_APPAPI.Models
{
    public partial class Organization
    {

        [Key]
        public int OrgID { get; set; }
        public string OrgName { get; set; }
        public string OrgEmailAdd { get; set; }
        public string OrgConNumber { get; set; }
        public string OrgAddress { get; set; }
        public int PostCode { get; set; }
  

    }
    public class record1
    {
        public int OrgID { get; set; }
        public string OrgName { get; set; }
        public string OrgEmailAdd { get; set; }
        public string OrgConNumber { get; set; }
        public string OrgAddress { get; set; }
        public int PostCode { get; set; }
        public int OrgType_ID { get; set; }
        public string OrgType_name { get; set; }
        public string Description { get; set; }

    }
}