﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LicensePortal_APPAPI.Models
{
    public class Org_Products
    {
        [Key]
        public int OrgProductID { get; set; }
        public int OrgID { get; set; }
        public int ProductID { get; set; }

    }
}
