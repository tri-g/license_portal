﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LicensePortal_APPAPI.Models
{
    public class Org_User
    {
        [Key]
        public int OrgUserID { get; set; }
        public int UserID { get; set; }
        public int OrgID { get; set; }
    }
}
